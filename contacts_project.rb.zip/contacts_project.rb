#the minimum: 
#a menu that allows creation of contact, view all contacts, exit
#when I run this program, I want it to say something like "Welcome to Your Contacts
# "How Can We Help?" and then have the menu options
# the menu should work by just selecting options 1, 2, 3, whatever, and then
# running that particular function 
#at the end of each function, should be a way to get back to the menu or to exit 
# "To return to menu, enter blah, to exit, enter blah" 

$contact_id = 1 
$contact_ids = []
$contact_names = []



#the menu 
def menu 
    puts "Welcome to Your Contacts. How Can We Help You?"
    puts "1. Create a New Contact"
    puts "2. View All Contacts"
    puts "3. Exit"
    print "> "
    selection = $stdin.gets.chomp
    if selection == "Create a New Contact"
        create_contact 
    elsif selection == "View All Contacts"
        view_contacts
    elsif selection == "exit"
        exit
    else 
        puts "Invalid Selection"
    end 
    after_selection
end 

def after_selection
    puts "Would you like to return to Main Menu, Yes or No?"
    print "> "
    selection = $stdin.gets.chomp
    if selection == "Yes" 
        menu
    elsif selection == "No"
        exit  
    end  
end 

#create a contact 
def create_contact
    puts "Please enter contact name followed by a comma, followed by their phone number."
# saving the user input to a new variable called "contact" 
    contact = gets
# puts the contact_id variable inside the contact_ids array 
    $contact_ids.push($contact_id)
# puts whatever the user gave us into contact_names array 
    $contact_names.push(contact)
# adds 1 to the contact_id variable 
    $contact_id = $contact_id + 1 
end 


#view all contacts
def view_contacts
# creates a loop that uses a variable to count through the contact_ids list
# and the contact_names list and prints them. Three dots excludes the last item.
    for x in (0...$contact_ids.count)
        puts "#{$contact_ids[x]} #{$contact_names[x]}" 
    end 
end 

#exit

menu


#-----below this line is extra if I have time-------#


# delete a contact 


# edit a contact 


# ability to view deleted contacts? 


# would be amazing if it can alphabetize the names somehow 